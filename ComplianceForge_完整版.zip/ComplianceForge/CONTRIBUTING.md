# Contributing to ComplianceForge

Thank you for your interest in improving ComplianceForge!

## How to Contribute

1. **Fork** the repository
2. Create a new branch: `git checkout -b feature/your-feature-name`
3. Make your changes
4. Run tests: `pytest tests/`
5. Commit with clear message: `git commit -m "feat: add new regulatory parser"`
6. Push and open a Pull Request

## Development Setup

```bash
git clone https://github.com/ComplianceForge/ComplianceForge.git
cd ComplianceForge
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

## Code Style

- Follow PEP 8
- Use type hints
- Add docstrings for all public functions
- Keep agent prompts under 800 tokens when possible

## Reporting Issues

Please use the [GitHub Issues](https://github.com/ComplianceForge/ComplianceForge/issues) page and include:
- Steps to reproduce
- Expected vs actual behavior
- Token usage (if applicable)

## License

By contributing, you agree that your contributions will be licensed under the Apache-2.0 License.
