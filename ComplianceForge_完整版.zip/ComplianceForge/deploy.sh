#!/bin/bash
#
# ComplianceForge 一键部署脚本
# Usage: ./deploy.sh [start|stop|logs|update]
#

set -e

PROJECT_NAME="ComplianceForge"
COMPOSE_FILE="docker-compose.yml"

echo "🚀 $PROJECT_NAME 一键部署脚本"
echo "=================================="

# Check if docker is installed
if ! command -v docker &> /dev/null; then
    echo "❌ Docker 未安装，请先安装 Docker"
    exit 1
fi

if ! command -v docker-compose &> /dev/null; then
    echo "❌ docker-compose 未安装，请先安装"
    exit 1
fi

case "$1" in
    start)
        echo "📦 启动 ComplianceForge..."
        docker-compose -f $COMPOSE_FILE up -d --build
        echo "✅ 部署成功！访问 http://localhost:8080"
        echo "📋 查看日志: ./deploy.sh logs"
        ;;
    stop)
        echo "🛑 停止 ComplianceForge..."
        docker-compose -f $COMPOSE_FILE down
        echo "✅ 已停止"
        ;;
    logs)
        docker-compose -f $COMPOSE_FILE logs -f
        ;;
    update)
        echo "🔄 更新 ComplianceForge..."
        docker-compose -f $COMPOSE_FILE pull
        docker-compose -f $COMPOSE_FILE up -d --build
        echo "✅ 更新完成"
        ;;
    *)
        echo "用法: $0 {start|stop|logs|update}"
        echo ""
        echo "示例:"
        echo "  $0 start    # 启动服务"
        echo "  $0 stop     # 停止服务"
        echo "  $0 logs     # 查看实时日志"
        echo "  $0 update   # 更新并重启"
        exit 1
        ;;
esac
