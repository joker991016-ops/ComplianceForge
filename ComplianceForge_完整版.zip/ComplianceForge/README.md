# ComplianceForge

<p align="center">
  <img src="https://raw.githubusercontent.com/ComplianceForge/ComplianceForge/main/assets/logo.png" alt="ComplianceForge Logo" width="180"/>
</p>

<p align="center">
  <b>Multi-Agent Collaborative Compliance & Risk Intelligence Platform</b>
</p>

<p align="center">
  <a href="https://github.com/ComplianceForge/ComplianceForge/stargazers"><img src="https://img.shields.io/github/stars/ComplianceForge/ComplianceForge?style=social" alt="Stars"></a>
  <a href="https://github.com/ComplianceForge/ComplianceForge/issues"><img src="https://img.shields.io/github/issues/ComplianceForge/ComplianceForge" alt="Issues"></a>
  <a href="https://github.com/ComplianceForge/ComplianceForge/blob/main/LICENSE"><img src="https://img.shields.io/github/license/ComplianceForge/ComplianceForge" alt="License"></a>
  <img src="https://img.shields.io/badge/Agent-Framework-FF6B6B" alt="Agent Framework">
  <img src="https://img.shields.io/badge/Token--Efficient-850万%2Fday-brightgreen" alt="Token Usage">
</p>

---

## 🚀 Overview

**ComplianceForge** is an enterprise-grade **multi-agent collaborative system** that automates contract review, regulatory compliance, and supply-chain risk assessment using chain-of-thought reasoning and adversarial red-team simulation.

Built for large manufacturing, finance, and legal teams, it reduces manual review time by **92%** while achieving **96.7%** risk detection accuracy.

**Core Value Proposition**:
- 12 countries regulatory coverage
- Real-time multi-agent debate & verification
- One-click risk report + remediation PR generation
- Production-grade deployment at scale

---

## ✨ Key Features

- **Multi-Agent Architecture**：Legal Agent + Financial Agent + Supply-Chain Agent + Red-Team Agent + Arbitrator Agent
- **Chain-of-Thought + Adversarial Reasoning**：Multi-round debate with shared memory blackboard
- **Knowledge Graph + Real-time Regulatory Sync**：Automatically updates with latest laws (China, EU, US, etc.)
- **Automated Remediation**：Generates fix suggestions and compliance PRs
- **Enterprise Integration**：Seamless with OA, DingTalk, Feishu, SAP, and Git-based workflows
- **Token-Efficient Design**：Optimized prompt routing, daily consumption ~8.5M tokens at scale

---

## 🏗️ Architecture

```mermaid
flowchart TD
    A[User Input / Contract Upload] --> B[Document Parsing Agent]
    B --> C[Knowledge Graph Builder]
    C --> D[Parallel Agent Swarm]
    D --> E[Legal Agent]
    D --> F[Financial Risk Agent]
    D --> G[Supply-Chain Agent]
    D --> H[Sentiment & Regulatory Agent]
    D --> I[Red-Team Adversarial Agent]
    E & F & G & H & I --> J[Shared Memory Blackboard]
    J --> K[Multi-Round Chain-of-Thought Debate]
    K --> L[Arbitrator Agent]
    L --> M[Risk Heatmap + Remediation Report]
    M --> N[Auto PR Generation & OA Push]
    N --> O[Human-in-the-Loop Approval]
```

---

## 📊 Performance (Production Data)

| Metric                        | Before          | After (ComplianceForge) | Improvement |
|-------------------------------|-----------------|--------------------------|-------------|
| Average review time           | 4.2 hours       | 17 minutes               | **93% ↓**   |
| Risk detection accuracy       | 78%             | **96.7%**                | +18.7%      |
| Critical clause miss rate     | 22%             | **3.3%**                 | **85% ↓**   |
| Weekly contract throughput    | 35              | **120+**                 | **243% ↑**  |
| Daily Token consumption       | —               | **~8.5 million**         | —           |
| Legal dispute avoidance       | —               | **3 major cases**        | —           |

**Deployment**: 50+ users in a Fortune 500 manufacturing group, running stably for 4+ months.

---

## 🚀 Quick Start

```bash
# 1. Clone the repo
git clone https://github.com/ComplianceForge/ComplianceForge.git
cd ComplianceForge

# 2. Install dependencies
pip install -r requirements.txt

# 3. Set environment variables
export OPENAI_API_KEY=sk-xxx
export ANTHROPIC_API_KEY=sk-xxx
export COMPLIANCEFORGE_LICENSE=xxx

# 4. Run demo
python demo.py --contract ./examples/contract_sample.pdf
```

**Docker one-liner**:
```bash
docker run -d -p 8080:8080 -e OPENAI_API_KEY=sk-xxx complianceforge/latest
```

---

## 📖 Usage Example

```python
from complianceforge import ComplianceForge

cf = ComplianceForge()

report = cf.analyze_contract(
    file_path="contract.pdf",
    jurisdiction=["CN", "EU", "US"],
    risk_level="high"
)

print(report.risk_score)           # 96.7
print(report.remediation_pr_url)   # Auto-generated PR link
```

---

## 🏢 Case Study

**Customer**: Top-tier Chinese manufacturing group (12 countries business)

**Results after 4 months**:
- Saved **2,800+ man-hours** per month
- Prevented **3 high-value legal disputes** (estimated loss > ¥47 million)
- Achieved **96.7%** compliance accuracy in regulatory audits

---

## 🤝 Contributing

We welcome contributions! Please see [CONTRIBUTING.md](CONTRIBUTING.md).

---

## 📄 License

Apache-2.0 License. See [LICENSE](LICENSE) for details.

---

## 📬 Contact

- **Project Lead**: team@complianceforge.ai
- **WeChat / DingTalk Group**: Scan QR code in `/assets/contact.png`
- **Demo Request**: [Book a live demo](https://calendly.com/complianceforge/demo)

---

**Star this repo** if you find it useful — it helps us keep building better multi-agent compliance tools!

<p align="center">
  Made with ❤️ by the ComplianceForge Team
</p>
