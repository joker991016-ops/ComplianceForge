#!/usr/bin/env python3
"""
ComplianceForge Demo
Run: python demo.py --contract ./examples/contract_sample.pdf
"""

import argparse
import json
from datetime import datetime
from rich.console import Console
from rich.table import Table
from rich.panel import Panel

console = Console()

def analyze_contract(contract_path: str, jurisdiction: list = None):
    """Simulated multi-agent analysis"""
    if jurisdiction is None:
        jurisdiction = ["CN", "EU", "US"]
    
    console.print(Panel.fit("[bold green]🚀 ComplianceForge Multi-Agent Analysis Started[/bold green]"))
    
    # Simulated agent outputs
    agents = {
        "Legal Agent": "✅ 12 critical clauses reviewed | 3 high-risk terms flagged",
        "Financial Agent": "✅ Penalty & liability simulation complete | Max exposure: ¥8.7M",
        "Supply-Chain Agent": "✅ 7 suppliers risk-scored | 2 high-risk vendors identified",
        "Red-Team Agent": "✅ Adversarial stress test passed | 4 edge cases simulated",
        "Arbitrator Agent": "✅ Final risk score: 96.7/100"
    }
    
    table = Table(title="Agent Collaboration Results", show_header=True)
    table.add_column("Agent", style="cyan")
    table.add_column("Output", style="green")
    
    for agent, output in agents.items():
        table.add_row(agent, output)
    
    console.print(table)
    
    report = {
        "contract": contract_path,
        "timestamp": datetime.now().isoformat(),
        "risk_score": 96.7,
        "jurisdiction": jurisdiction,
        "flagged_clauses": 3,
        "remediation_suggestions": [
            "Add force majeure clause (Art. 12.3)",
            "Revise payment terms to Net-45",
            "Insert data protection addendum (GDPR Art. 28)"
        ],
        "estimated_savings": "¥2.4M / year",
        "token_consumed": 12480
    }
    
    console.print(Panel.fit(
        f"[bold]Risk Score:[/bold] [green]{report['risk_score']}/100[/green]\n"
        f"[bold]Estimated Annual Savings:[/bold] [yellow]{report['estimated_savings']}[/yellow]\n"
        f"[bold]Tokens Used:[/bold] {report['token_consumed']}",
        title="📊 Final Report Summary",
        border_style="green"
    ))
    
    # Simulate PR generation
    console.print("\n[bold cyan]🔗 Auto-generated Remediation PR:[/bold cyan]")
    console.print("https://github.com/company/contracts/pull/1247")
    
    return report

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--contract", default="./examples/contract_sample.pdf")
    args = parser.parse_args()
    
    analyze_contract(args.contract)
